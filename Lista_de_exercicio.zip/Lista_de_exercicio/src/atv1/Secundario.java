package atv1;

public class Secundario {
	public static void tabuada (int a) {
		int b = 0, c;
		
		while (b <= 10) {
			c = a * b;
			System.out.println(c);
			b++;
		}
}
}