package atv3;


public class Principal {

	public static void main(String[] args) {
		
		Secundario.fibo();
			
		}


	} 

    