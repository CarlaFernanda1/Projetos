package atv6;

public class Secundario {
	public static double salario (double hora) {
		double salario;
		
		salario = 12.25*hora;
		
		return salario;
	}
}
