package atv3;

public class Secundario {
	public static void fibo () {
	int x = 0;
	int y = 1;
	
	for (int i = 0; i < 12; i++) {
		
		System.out.println(y);
		
		y = y + x;
		
		x = y - x;	
		
	}
	}
}